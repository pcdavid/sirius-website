package org.eclipse.sirius.sample.basicfamily.services;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EObject;

import basicfamily.Family;
import basicfamily.Person;

public class FamilyServices {
			
	public List<Person> getMembersWithoutMother(Person person) {
		Family family=(Family)person.eContainer();
		List<Person> result=new ArrayList<Person>();
		for (Person person2 : family.getMembers()) {
			if (person2.getMother()==null)
				result.add(person2);
		}
		return result;
	}
}
